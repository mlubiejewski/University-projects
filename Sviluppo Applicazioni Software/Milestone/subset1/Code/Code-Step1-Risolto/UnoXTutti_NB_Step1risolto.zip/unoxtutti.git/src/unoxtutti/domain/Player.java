/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package unoxtutti.domain;

import java.io.Serializable;

/**
 *
 * @author picardi
 */
public class Player implements Serializable {
	private String name;
	private int id;
	
	private Player() {};
	
	public static Player createPlayer(RegisteredPlayer reg) {
		Player pl = new Player();
		pl.name = reg.getUserName();
		pl.id = reg.getId();
		return pl;
	}
}
