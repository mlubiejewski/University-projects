/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package unoxtutti.domain;

/**
 *
 * @author picardi
 */
public class RegisteredPlayer {
	private int id;
	protected final String userName;
	protected final String password;
	protected final String email;

	public int getId() {
		return id;
	}
	
	public RegisteredPlayer(String userName, String email, String password) {
		this.userName = userName;
		this.password = password;
		this.email = email;
	}

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}
}
