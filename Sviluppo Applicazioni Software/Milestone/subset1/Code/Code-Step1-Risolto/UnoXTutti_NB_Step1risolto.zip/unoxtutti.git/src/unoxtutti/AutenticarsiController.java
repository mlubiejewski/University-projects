/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package unoxtutti;

import java.net.InetAddress;
import java.net.UnknownHostException;
import unoxtutti.domain.Player;
import unoxtutti.webclient.WebClientConnection;

/**
 *
 * @author picardi
 */
public class AutenticarsiController {
	
	private static AutenticarsiController singleInstance;
	private Player thePlayer;
	private AutenticarsiController() {}
	private WebClientConnection webCliConn;
	
	public static AutenticarsiController getInstance() {
		if (singleInstance == null) singleInstance = new AutenticarsiController();
		return singleInstance;
	}
	
	
	public boolean registra(String userName, String email, String password) {
		return webCliConn.createUser(userName, email, password);
	}
	
	public Player accedi(String email, String password) {
		thePlayer = webCliConn.verify(email, password);
		return thePlayer;
	}
	
	boolean initialize() {
		try {
			webCliConn = new WebClientConnection(InetAddress.getByName(UnoXTutti.WEB_ADDRESS), UnoXTutti.WEB_PORT);
		} catch (UnknownHostException ex) {
			System.out.println("Host " + UnoXTutti.WEB_ADDRESS + " sconosciuto.");
			return false;
		}
		return true;
	}

	/**
	 * @return the thePlayer
	 */
	public Player getPlayer() {
		return thePlayer;
	}
	
}
