/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package unoxtutti;

import unoxtutti.gui.AutenticarsiGUI;

/**
 *
 * @author picardi
 */
public class UnoXTutti {

	public static AutenticarsiController theAutController;
	public static String WEB_ADDRESS = "localhost";
	public static int WEB_PORT = 9000;
	
	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
		// PRIMO PASSO: inizializzare il controller di Autenticarsi e mostrare la GUI
		
		theAutController = AutenticarsiController.getInstance();
		boolean ok = theAutController.initialize();
		if (!ok) {
			System.out.println("Problemi di inizializzazione dell'autenticazione. Termino.");
			return;
		}
		AutenticarsiGUI autDialog = new AutenticarsiGUI(null, true);
		autDialog.setVisible(true);
		autDialog.dispose();
		
		// Capiamo che Autenticarsi ha avuto successo dal fatto che il controller di
		// Autenticarsi ha ottenuto un Player
		
		if (theAutController.getPlayer() == null) // usciamo
			return;
		
	}	
}
