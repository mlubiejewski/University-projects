/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package unoxtutti.webclient;

import java.net.InetAddress;
import unoxtutti.domain.Player;

/**
 *
 * @author picardi
 */
public class WebClientConnection {

	protected final InetAddress ipAddress;
	protected final int port;


	public WebClientConnection(InetAddress ip, int port) {
		ipAddress = ip;
		this.port = port;
	}

	public boolean createUser(String userName, String email, String password) {
		//TODO
		return  false;
	}

	public Player verify(String email, String password) {
		//TODO 
		return null;
	}

	/**
	 * @return the ipAddress
	 */
	public InetAddress getIpAddress() {
		return ipAddress;
	}

	/**
	 * @return the port
	 */
	public int getPort() {
		return port;
	}
}
