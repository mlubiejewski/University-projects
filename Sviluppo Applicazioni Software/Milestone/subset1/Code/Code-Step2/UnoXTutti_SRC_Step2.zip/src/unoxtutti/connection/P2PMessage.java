/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package unoxtutti.connection;

import java.io.Serializable;

/**
 *
 * @author picardi
 */
public class P2PMessage implements Serializable {
	private final static String IDENTIFICATION_MSG = "___ID___";
	private final static String BYE_MSG = "___BYE___";
	private final static String CONNECTIONACCEPTED_MSG = "___CONNACC___";
	private String name;
	private Object[] parameters;
	
	private P2PMessage() {
	}
	
	public String getName() {
		return name;
	}

	public boolean isByeMessage() {
		return this.name.equals(BYE_MSG);
	}
	
	public static P2PMessage createByeMessage() {
		P2PMessage msg = new P2PMessage();
		msg.name = BYE_MSG;
		return msg;
	}
	
	
	public Object getParameter(int i) {
		if (i < 0 || i >= parameters.length) return null;
		return  parameters[i];
	}
	
	public int getParametersCount() {
		return parameters.length;
	}
}
