/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package unoxtutti.domain;

import java.io.Serializable;

/**
 *
 * @author picardi
 */
public class Player implements Serializable {
	private String name;
	private int id;
	
	private Player() {};
	
	public static Player createPlayer(RegisteredPlayer reg) {
		Player pl = new Player();
		pl.id = reg.getId();
		pl.name = reg.getUserName();
		return pl;
	}
	
	public String getName() {
		return name;
	}
}
