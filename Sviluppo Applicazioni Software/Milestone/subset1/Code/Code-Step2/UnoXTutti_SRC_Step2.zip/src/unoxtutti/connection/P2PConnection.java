/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package unoxtutti.connection;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import unoxtutti.domain.Player;

/**
 * Questa classe rappresenta una connessione "alla pari". Solo inizialmente
 * serve sapere chi &egrave; il Client (colui che richiede la connessione) e chi
 * il Server (colui che la concede) per gestire l'handshake iniziale.
 *
 * @author picardi
 */
public class P2PConnection {

	private class P2PHelper implements Runnable {

		@Override
		public void run() {
			P2PMessage lastMsg = null;
			do {
				try {
				lastMsg = (P2PMessage) sockIn.readObject();
				//System.out.println((serverSide ? "Server: " : "Client: ") + "Received message: " + lastMsg.getName());
				if (lastMsg.isByeMessage() && !isClosing()) {
					//System.out.println("Current thread writing message: " + Thread.currentThread().toString());
					//System.out.println("Current output stream: " + sockOut.toString());
					sendMessage(P2PMessage.createByeMessage());
					setClosing(true);
					//Thread.sleep(10000);
				}}
				catch(IOException | ClassNotFoundException ex) {
					//System.out.println("Exception in " + (serverSide ? "Server: " : "Client: "));
					ex.printStackTrace();
				}
				// TODO in Step3: DO SOMETHING WITH MESSAGE
			} while (!isClosing());
			doClose();
		}
	}

	private final Socket mySocket;
	private final boolean serverSide;
	private ObjectInputStream sockIn;
	private ObjectOutputStream sockOut;
	private P2PHelper myHelper;
	private Player player;
	private boolean closed;
	private boolean closing;

	private P2PConnection(Socket sock, boolean serverside) {
		mySocket = sock;
		this.serverSide = serverside;
		closed = false;
	}

	private void doClose() {
		try {
			//System.out.println("Current thread closing: " + Thread.currentThread().toString());
			//System.out.println("Closing output stream: " + sockOut.toString());			
			sockOut.close();
			sockIn.close();
		} catch (IOException ex) {
			Logger.getLogger(P2PConnection.class.getName()).log(Level.SEVERE, null, ex);
		} finally {
			try {
				mySocket.close();
			} catch (IOException ex) {
				Logger.getLogger(P2PConnection.class.getName()).log(Level.SEVERE, null, ex);
			}
			setClosed();
		}
	}
	
	public synchronized void sendMessage(P2PMessage msg) {
		try {
			sockOut.writeObject(msg);
		} catch (IOException ex) {
			Logger.getLogger(P2PConnection.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	private void connect() throws IOException, ServerConnectionException {
		if (serverSide) {
			sockIn = new ObjectInputStream(mySocket.getInputStream());
			sockOut = new ObjectOutputStream(mySocket.getOutputStream());
			boolean ok = handshake();
			if (!ok) {
				throw new ServerConnectionException("Could not handshake");
			}
		} else {// clientside 
			sockOut = new ObjectOutputStream(mySocket.getOutputStream());
			sockIn = new ObjectInputStream(mySocket.getInputStream());
			boolean ok = handshake();
			if (!ok) {
				throw new ClientConnectionException("Could not handshake");
			}
		}
		myHelper = new P2PHelper();
		(new Thread(myHelper)).start();
	}

	private boolean handshake() throws IOException {
		boolean ok = true;
		// TODO in Step 3
		return ok;
	}

	/**
	 * Accept a new connection from a client. In order for the connection to
	 * work, the client should create an output and an input stream (in this
	 * order).
	 *
	 * @param serverSock the server Socket
	 * @return the P2PConnection with the new client
	 * @throws IOException, ServerConnectionException
	 */
	public static P2PConnection acceptConnectionRequest(ServerSocket serverSock) throws IOException, ServerConnectionException {
		Socket clientsock = serverSock.accept();
		P2PConnection p2p = new P2PConnection(clientsock, true);
		p2p.connect();
		return p2p;
	}

	/**
	 * TODO
	 *
	 * @param address
	 * @param port
	 * @return
	 * @throws IOException
	 */
	public static P2PConnection connectToHost(Player player, InetAddress address, int port) throws IOException {
		Socket clientsock = new Socket(address, port);
		P2PConnection p2p = new P2PConnection(clientsock, false);
		p2p.player = player;
		p2p.connect();
		return p2p;
	}

	/**
	 * Restituisce il giocatore associato con questa connessione.
	 *
	 * @return il Player associato con questa connessione.
	 */
	public Player getPlayer() {
		return player;
	}

	/**
	 * Chiede alla connessione di chiudersi. Essa manda un Bye message sul
	 * canale (vedasi P2PMessage). Ci&ograve; che effettivamente chiude
	 * per&ograve; &egrave; la ricezione di una risposta al Bye. Se qualcosa va
	 * storto la connessione viene chiusa bruscamente richiamando forceClose.
	 */
	public synchronized void closeDown() {
		try {
			setClosing(true);
			sockOut.writeObject(P2PMessage.createByeMessage());
		} catch (IOException ex) {
			System.out.println("Could not close down gracefully.");
			forceClose();
		}
	}

	/**
	 * Dice se la connessione &egrave; chiusa.
	 *
	 * @return true se la connessione &egrave; chiusa, false altrimenti.
	 */
	public synchronized boolean isClosed() {
		return closed;
	}

	private synchronized void setClosed() {
		closed = true;
	}

	private synchronized boolean isClosing() {
		return closing;
	}

	private synchronized void setClosing(boolean b) {
		closing = b;
	}

	/**
	 * Forza la chiusura brusca e improvvisa della connessione.
	 *
	 */
	public synchronized void forceClose() {
		if (closed) {
			return;
		}
		doClose();
		closed = true;
	}
}
